


<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row text-light">
            <div class="col-3 border-right border-secondary" style="border-width: 2px!important;">
                <div class="ml-3">
                    <div style="font-size: 40px"> Similar</div>
                    <?php $__currentLoopData = $similar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paper): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div>
                            <a href="/question-paper/<?php echo e($paper->id); ?>"
                               title="<?php echo e($paper->paper_name); ?>"
                            ><?php echo e($paper->name); ?> (<?php echo e($paper->year); ?>)</a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="col-6 offset-1">
                <div class="container text-center ">
                    <div style="font-size: xx-large;">
                        <?php echo e($questionPaper->code); ?>

                    </div>
                    <div style="font-size: x-large;" class="d-inline">
                        <?php echo e($questionPaper->name); ?> - <?php echo e($questionPaper->year); ?>

                    </div>
                    <div class="d-inline">
                        (<a href="<?php echo e($questionPaper->url); ?>">Download link</a>)
                    </div>

                    <table class="table table-dark m-auto">
                        <thead>
                        <th>
                            Available answers
                        </th>
                        </thead>
                        <?php $__empty_1 = true; $__currentLoopData = $answers_number_and_char; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a_n_c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td>
                                    <a href="<?php echo e(url()->current() . '/answer/' . $a_n_c->question_number . '/' . $a_n_c->sub_question_character); ?> ">
                                        Question <?php echo e($a_n_c->question_number); ?>

                                        Part <?php echo e($a_n_c->sub_question_character); ?>

                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td>There are no answers at the moment. Add yourself!</td>
                            </tr>
                        <?php endif; ?>
                    </table>

                    <form action="/question-paper/<?php echo e($questionPaper->id); ?>/answer-add">
                        <button class="btn btn-outline-success m-3">Add Answer</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('head'); ?>
    <style>
        a {
            text-decoration: none !important;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\SEM-6\NIRMA PAPER SOLUTION\nirma_paper_solution_website\resources\views/questionpaper/answerlinks.blade.php ENDPATH**/ ?>