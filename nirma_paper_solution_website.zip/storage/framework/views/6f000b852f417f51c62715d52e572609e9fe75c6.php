<?php echo e($slot); ?>

<?php /**PATH E:\SEM-6\NIRMA PAPER SOLUTION\nirma_paper_solution_website\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>