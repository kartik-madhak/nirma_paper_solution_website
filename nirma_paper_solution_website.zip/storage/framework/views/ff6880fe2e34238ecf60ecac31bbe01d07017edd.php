

<h2>Hello Admin,</h2>
You received an email from : <?php echo e($name); ?>

<hr>
Here are the details:
<hr>
<b>Name:</b> <?php echo e($name); ?>

<hr>
<b>Email:</b> <?php echo e($email); ?>

<hr>
<b>Message:</b> <?php echo e($content); ?>

<hr>
Thank You

<?php /**PATH E:\SEM-6\NIRMA PAPER SOLUTION\nirma_paper_solution_website\resources\views/email/contactmail.blade.php ENDPATH**/ ?>