

<?php $__env->startSection('head'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>"/>
    <script src="https://polyfill.io/v3/polyfill.min.js?features=es6"></script>
    <script id="MathJax-script" async
            src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js">
    </script>

    <link rel="stylesheet"
          href="//cdnjs.cloudflare.com/ajax/libs/highlight.js/10.5.0/styles/default.min.css">

    <link rel="stylesheet" href="<?php echo e(asset('css/dracula.css')); ?>">
    <script src="//cdnjs.cloudflare.com/ajax/libs/highlight.js/10.5.0/highlight.min.js"></script>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons"
          rel="stylesheet">

    <script>hljs.initHighlightingOnLoad();</script>



    
    
    
    <style>

        @media  only screen and (max-width: 600px) {
            .tablet-hidden {
                display: none;
            }
        }

        @media  only screen and (max-width: 768px) {
            .mobile-hidden {
                display: none;
            }
        }

        .math-tex {
            font-size: 18px;
            padding: 20px;
            background-color: #1C1B1B;
            border-radius: 10px;
        }

    </style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="text-center text-light">
        <div style="font-size: xx-large;">
            <?php echo e($questionPaper->code); ?>

        </div>
        <div style="font-size: x-large;" class="d-inline">
            <?php echo e($questionPaper->name); ?> - <?php echo e($questionPaper->year); ?>

        </div>
        <div class="d-inline">
            (<a href="<?php echo e($questionPaper->url); ?>">Download link</a>)
        </div>
        </div>
        <div class="row">
            <div class="col-md-2 text-light border-right mobile-hidden"
                 style="background-color: #2D2D2D; border-color: #404345!important;">
                <div class="mt-2">
                    <div class="sidebar-header">
                        <h3>Quick Links</h3>
                    </div>
                    <div>
                        <?php $__empty_1 = true; $__currentLoopData = $answers_number_and_char; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a_n_c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div>
                                <a href="/question-paper/<?php echo e($questionPaper->id . '/answer/' . $a_n_c->question_number . '/' . $a_n_c->sub_question_character); ?> ">
                                    Question <?php echo e($a_n_c->question_number); ?> Part <?php echo e($a_n_c->sub_question_character); ?>

                                </a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td>There are no answers at the moment. Add yourself!</td>
                            </tr>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="col-md-8" style="font-size: 14px;">
                <div class="ml-4">
                    <?php $__empty_1 = true; $__currentLoopData = $answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="row border-bottom border-top text-light"
                             style="background-color: #2D2D2D; border-color: #404345!important;" id="<?php echo e($answer->id); ?>">

                            <div class="col-1 mt-4">
                                <div style="cursor: pointer; font-size: 13px;">
                                    <span class="material-icons clickEvent <?php echo e($answer->likedByUser ? 'text-primary':''); ?>"
                                          id="<?php echo e($answer->id); ?>"
                                          style="font-size: 17px">
                                        thumb_up
                                    </span>
                                    <span id="<?php echo e('likeNumber' . $answer->id); ?>" class="ml-1">
                                        <?php echo e($answer->likes); ?>

                                    </span>
                                </div>
                            </div>

                            <div class="p-4 col-11">
                                <div>
                                    <?php echo $answer->content; ?>

                                </div>
                                <div class="footer float-right" style="font-size: 13px">
                                    <?php echo e($answer->user->name . ' at ' . $answer->created_at); ?>

                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="rounded-lg p-3">
                            There are no answers at this moment
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-md-2 tablet-hidden">
                <div class="text-light">
                    <div class="ml-1">
                        <div style="font-size: x-large">
                            All Answers
                        </div>
                        <?php $__currentLoopData = $answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="mb-2 d-flex">
                                <a href="#" class="mr-2">
                                    <div class="rounded-lg bg-success text-center"
                                         style="width: 30px; height: 20px; text-decoration: none; color: white">
                                        <?php echo e($answer->likes); ?>

                                    </div>
                                </a>
                                <a href="#<?php echo e($answer->id); ?>">
                                    <?php echo e($answer->user->name); ?>

                                </a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $(document).ready(function () {
            $(".clickEvent").click(function () {
                const obj = $(this);

                let pp = $(this).attr("id");
                $.post("/answer/" + pp + "/like", {_token: '<?php echo e(csrf_token()); ?>'},
                    function (answer) {
                        console.log(answer);
                        obj.toggleClass("text-primary");
                        $("#likeNumber" + answer.id).html(answer.likes);
                    }).fail(function (data) {
                    console.log(data);
                });
            });
        });
    </script>
    
    
    
    

    
    
    

    
    
    
    
    

    

    
    
    
    
    
    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\SEM-6\NIRMA PAPER SOLUTION\nirma_paper_solution_website\resources\views/answer/show.blade.php ENDPATH**/ ?>