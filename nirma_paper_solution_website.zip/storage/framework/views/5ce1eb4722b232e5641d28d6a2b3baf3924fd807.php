<?php $__env->startSection('content'); ?>

    <div class="container-fluid">
    <div class="row">
        <div class="col-lg-2 mt-3 text-center">
            <table class="table table-dark table-striped m-auto table-responsive " style="width: fit-content">
                <thead>
                <th>
                    Users online in the last 1 minute
                </th>
                </thead>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($user->isOnline()): ?>
                        <tr>
                            <td><?php echo e($user->name); ?></td>
                        </tr>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    <div class="text-center col-lg-10 mt-3">

        <div class="active-cyan-4 mb-3">
            <form action="">
                <div class="input-group mb-3">
                    <input type="text" class="form-control" name="search" placeholder="Search" value="<?php echo e($search); ?>">
                    <div class="input-group-append">
                        <button class="btn btn-outline-success" type="submit">Search</button>
                    </div>
                </div>
            </form>
        </div>

        <div class="table-responsive">

        <table id="data-table" class="display table table-striped table-dark table-hover">
            <thead>
            <tr>
                <th>Link</th>
                <th>Paper Name</th>
                <th>Answers Link</th>
                <th>Course Name</th>
                <th>Course Code</th>
                <th>Paper Year</th>

            </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $papers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paper): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><a href="<?php echo e($paper->url); ?>">Download here</a></td>
                        <td><?php echo e($paper->paper_name); ?></td>
                        <td><a href="/question-paper/<?php echo e($paper->id); ?>">Answers</a></td>
                        <td><?php echo e($paper->name); ?></td>
                        <td><?php echo e($paper->code); ?></td>
                        <td><?php echo e($paper->year); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>

        </table>
            <div class="text-center d-inline-flex">
                <?php echo e($papers->links()); ?>

            </div>
        </div>
    </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\SEM-6\NIRMA PAPER SOLUTION\nirma_paper_solution_website\resources\views/home.blade.php ENDPATH**/ ?>