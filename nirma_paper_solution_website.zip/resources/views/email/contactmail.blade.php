

<h2>Hello Admin,</h2>
You received an email from : {{ $name }}
<hr>
Here are the details:
<hr>
<b>Name:</b> {{ $name }}
<hr>
<b>Email:</b> {{ $email }}
<hr>
<b>Message:</b> {{ $content }}
<hr>
Thank You

